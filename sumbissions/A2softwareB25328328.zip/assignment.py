#%% [markdown]
# ### Question 1: Data Understanding and Exploration

import pandas as pd 
from IPython.display import display

df = pd.read_csv('ecg_curated.csv', header=None)

display(df.head())

#(rows, columns)
display(df.shape)

#separating features
x = df.iloc[:, :-1]   
y = df.iloc[:, -1]    

#normal and abnormal counts
display(y.value_counts())

#feature statistics
display(x.describe())

#missing values
display(df.isnull().sum())


#%%
#Number of unique classes
num_classes = y.nunique()

print("Number of classes:", num_classes)

if num_classes > 2:
    print("The label column is MULTICLASS")
else:
    print("The label column is BINARY")


#%%
import matplotlib.pyplot as plt

#plot first 3 heartbeats
for i in range(3):
    plt.plot(x.iloc[i])
    plt.title(f"Heartbeat {i}")
    plt.show()


#%%
#find one normal and one abnormal
import numpy as np

# find indices of each class
normal_idx = df[df.iloc[:, -1] == 0].index[0]
abnormal_idx = df[df.iloc[:, -1] == 1].index[0]

# extract signals (exclude last column = label)
normal = df.iloc[normal_idx, :-1].values
abnormal = df.iloc[abnormal_idx, :-1].values

# create x-axis
x_axis = np.arange(len(normal))

# plot
plt.plot(x_axis, normal, label="Normal")
plt.plot(x_axis, abnormal, label="Abnormal")

plt.xticks(np.arange(0, len(normal), 20))
plt.xlabel("Time Step")
plt.ylabel("Amplitude")
plt.title("Normal vs Abnormal Heartbeat")
plt.legend()
plt.show()




#%% [markdown]
# ### Question 2: Data Preprocessing and Feature Engineering

from scipy.signal import find_peaks  #detects peaks(important heartbeat spikes) in ECG signal

features = []
labels = []


for _, row in df.iterrows():
    values = row.dropna().values #remove missing values

    label = values[-1]  
    signal = values[:-1]
    
    labels.append(label)

    #statistical features
    mean = np.mean(signal)
    std = np.std(signal)
    max_R = np.max(signal)
    min = np.min(signal)
    range = max_R - min

    #signal_based feature
    energy = np.sum(signal ** 2)  #total intensity or activity of the signal
    peaks, _ = find_peaks(signal)
    num_peaks = len(peaks)  #number of peaks in the signal

    features.append([mean, std, max_R, min, range, energy, num_peaks])


#convert to ABT (clean dataset with features and labels)
X_abt = pd.DataFrame(features, columns=['mean', 'std', 'max_R', 'min', 'range', 'energy', 'num_peaks'])
y_abt = pd.Series(labels)

abt = pd.concat([X_abt, y_abt.rename('label')], axis=1)

display(abt.head())


#Scaling for PCA (only applied to features, not labels or ABT)
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_abt)




# %% [markdown]
# ### Question 3: Correlation analysis between features and impact on Decsion Tree and Random Forest
import seaborn as sns

#correlation matrix
corr_matrix = abt.corr()
display(corr_matrix)

plt.figure(figsize=(8, 6))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm')
plt.title("Correlation Matrix of Features")
plt.show()




# %% [markdown]
# ### Question 4: PCA and its benefits

from sklearn.decomposition import PCA

pca = PCA(n_components=3)  #reduce to 3 dimensions
X_pca = pca.fit_transform(X_scaled)
pca_df = pd.DataFrame(X_pca, columns=['PC1', 'PC2', 'PC3'])
display(pca_df.head())

display(pca.explained_variance_ratio_) #proportion of variance explained by each principal component
total_variance = pca.explained_variance_ratio_.sum()
print("Total variance explained by the first 3 principal components:", total_variance)




# %% [markdown]
# ### Question 5: PCA correlation with target variable

pca_with_label = pd.concat([pca_df, y_abt.rename('label')], axis=1)
pca_corr = pca_with_label.corr()
display(pca_corr)

plt.figure(figsize=(8, 6))
sns.heatmap(pca_corr, annot=True, cmap='coolwarm')
plt.title("Correlation Matrix of PCA Components and Label")
plt.show()




# %% [markdown]
# ### Question 6: Forming train and test sets

n = len(abt) #total number of samples
display("Total samples in ABT:", n)

split_index = int((3/5) * n)

subset_A = abt.iloc[:split_index]  #first 3/5 for training
subset_B = abt.iloc[split_index:]  #last 2/5 for testing

display("Subset A size:", len(subset_A))
display("Subset B size:", len(subset_B))

# ### check class distribution in full dataset and subsets
display("Full dataset:")
display(abt['label'].value_counts(normalize=True))

display("Subset A:")
display(subset_A['label'].value_counts(normalize=True))

display("Subset B:")
display(subset_B['label'].value_counts(normalize=True))




# %% [markdown]
# ### Question 7: Building Decision Tree 

#training data
x_A = subset_A.drop(columns=['label'])
y_A = subset_A['label']

#testing data
x_B = subset_B.drop(columns=['label'])
y_B = subset_B['label']


#train Decision Tree
from sklearn.tree import DecisionTreeClassifier

dt = DecisionTreeClassifier(criterion='gini', max_depth=5, min_samples_split=10, min_samples_leaf=5, random_state=42)
dt.fit(x_A, y_A)

#predict on test set
y_pred_dt = dt.predict(x_B)

#confusion matrix and classification report
from sklearn.metrics import confusion_matrix, classification_report
cm = confusion_matrix(y_B, y_pred_dt)
display("Confusion Matrix:", cm)


#visualize confusion matrix
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix - Decision Tree')
plt.show()




# %% [markdown]
# ### Question 8: Building Random Forest
from sklearn.ensemble import RandomForestClassifier

rf = RandomForestClassifier(n_estimators=100, criterion='gini', max_depth=5, min_samples_split=10, min_samples_leaf=5, max_features='sqrt', random_state=42)
rf.fit(x_A, y_A)

#predict on test set
y_pred_rf = rf.predict(x_B)

#confusion matrix and classification report
cm_rf = confusion_matrix(y_B, y_pred_rf)
display("Confusion Matrix - Random Forest:", cm_rf)


#visualize confusion matrix
sns.heatmap(cm_rf, annot=True, fmt='d', cmap='Greens')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix - Random Forest')
plt.show()




# %% [markdown]
# ### Question 9: Comparing Decision Tree and Random Forest (F1-score)

from sklearn.metrics import f1_score

f1_dt = f1_score(y_B, y_pred_dt)
f1_rf = f1_score(y_B, y_pred_rf)

display("F1-score for Decision Tree:", f1_dt)
display("F1-score for Random Forest:", f1_rf)




# %% [markdown]
# ### Question 10: 10-fold Cross Validation
from sklearn.model_selection import cross_val_predict
from sklearn.model_selection import cross_val_score

x = abt.drop(columns=['label'])
y = abt['label']

# decision tree cross validation
f1_dt_scores = cross_val_score(dt, x, y, cv=10, scoring='f1')

# random forest cross validation
f1_rf_scores = cross_val_score(rf, x, y, cv=10, scoring='f1')

display("Decision Tree F1-scores from 10-fold CV:", f1_dt_scores)
display("Random Forest F1-scores from 10-fold CV:", f1_rf_scores)

display("Average F1-score for Decision Tree:", f1_dt_scores.mean())
display("Average F1-score for Random Forest:", f1_rf_scores.mean())

#aggregate confusion matrix decision tree
y_pred_dt_cv = cross_val_predict(dt, x, y, cv=10)
cm_dt_cv = confusion_matrix(y, y_pred_dt_cv)

plt.figure(figsize=(6, 5))
sns.heatmap(cm_dt_cv, annot=True, fmt='d', cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix - Decision Tree (10-fold CV)')
plt.show()

#aggregate confusion matrix random forest
y_pred_rf_cv = cross_val_predict(rf, x, y, cv=10)
cm_rf_cv = confusion_matrix(y, y_pred_rf_cv)

plt.figure(figsize=(6, 5))
sns.heatmap(cm_rf_cv, annot=True, fmt='d', cmap='Greens')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix - Random Forest (10-fold CV)')
plt.show()

#statistical significance test (paired t-test)
from scipy.stats import ttest_rel

t_stat, p_value = ttest_rel(f1_dt_scores, f1_rf_scores)

display("p-value from paired t-test:", p_value)


# %%
