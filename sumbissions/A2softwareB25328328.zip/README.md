ECG Classification Project

How to run:

1. Install dependencies:
   pip install -r requirements.txt

2. Run the script:
   assignment.py

Description:
This project performs ECG heartbeat classification using feature engineering, PCA, Decision Tree and Random Forest models.